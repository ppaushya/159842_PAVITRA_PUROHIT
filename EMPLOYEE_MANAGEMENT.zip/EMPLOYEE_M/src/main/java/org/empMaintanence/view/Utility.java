package org.empMaintanence.view;

import java.time.LocalDate;
import java.time.Period;

public class Utility {

	//VALIDATING EMPLOYEE ID
	public static boolean isValidEmpId(String empId) {
		return empId.matches("[1-9]{1}[0-9]{5}");

	}

	//VALIDATING EMPLOYEE FIRST NAME
	public static boolean isValidFirstName(String fname) {
		
		return fname.matches("[A-Za-z]{1,}");
	}

	//VALIDATING EMPLOYEE LAST NAME
	public static boolean isValidLastName(String lname) {
		
		return lname.matches("[A-Za-z]{1,}");
	}

	//VALIDATING EMPLOYEE DATE OF BIRTH
	public static boolean isValidDateOfBirth(String dob) {
		
		return dob.matches("[0-3][0-9]-[A-Za-z]{3}-[0-9][0-9]");
	}

	//VALIDATING EMPLOYEE DESIGNATION
	public static boolean isValidDesignation(String design) {
		
		return design.matches("[A-Za-z]+");
	}

	//VALIDATING EMPLOYEE HOME ADDRESS
	public static boolean isValidHomeAddress(String address) {
		
		return address.matches("[A-Za-z0-9\\s]*");
	}

	//VALIDATING EMPLOYEE CONTACT NUMBER
	public static boolean isValidContactNumber(String contactNo) {
		
		return contactNo.matches("[A-Za-z0-9\\s]*");
	}
	
	//VALIDATING EMPLOYEE BASIC
	public static boolean isValidBasic(int basic) {
		
		String str=new String();
		
		if(basic>=10000 && basic<=5000000 ) 
		{	
			 str=Integer.toString(basic);
			 return str.matches("[0-9]+");
			
		}else
			return false;
		
	}

	//VERIFICATION FOR BASIC IN ACCORDANCE WITH GRADE
	public static boolean basicGradeValidation(int basic, String grade) {
		
		if(basic>=10000 && basic<=25000 && grade=="M7")
			return true;
		else if(basic>=25000 && basic<=50000 && grade=="M6")
			return true;
		else if(basic>=50000 && basic<=100000 && grade=="M5")
			return true;
		else if(basic>=100000 && basic<=200000 && grade=="M4")
			return true;
		else if(basic>=200000 && basic<=500000 && grade=="M3")
			return true;
		else if(basic>=500000 && basic<=1000000 && grade=="M2")
			return true;
		else if(basic>=1000000 && basic<=5000000 && grade=="M1")
			return true;
		else
			return false;
		
	
}

	//VERIFYING DOB & DOJ RELATION
	public static boolean DobValidation(LocalDate dateOfBirth) {
		
		LocalDate currentdate=LocalDate.now();
		
		Period age=Period.between(dateOfBirth, currentdate);
		
		if(age.getYears()>=18 && age.getYears()<=58)
		{
			return true;
		}
		
		return false;
	}

	//VERIFYING DOB & DOJ RELATION
	public static boolean DojValidation(LocalDate dateOfJoining,LocalDate dateOfBirth) {

		if(dateOfJoining.isAfter(dateOfBirth))
		{
			return true;
		}
		return false;
	
	}
}
