import { Component, OnInit } from '@angular/core';
import { Inventory } from '../models/Inventory';
import { ByCategoryService } from './by-category.service';
import { Promos } from '../models/Promos';
import { PromoService } from '../promos/promo.service';
import { ProductService } from '../products/product-service.service';
@Component({
  selector: 'app-by-category',
  templateUrl: './by-category.component.html',
  styleUrls: ['./by-category.component.css']
})
export class ByCategoryComponent implements OnInit {
  inventory:Inventory[]
  categories:string[];
  promos:Promos[]=[];
  constructor(private _byCategoryService: ByCategoryService) { }
  
  ngOnInit() {
    this._byCategoryService.getProductCategory().subscribe(categories=>{
      this.categories=categories;
    });
    this._byCategoryService.getAllPromos().subscribe(promos=>{
      this.promos=promos;
    })
  }
  promoCode:string
  edit(){
    this._byCategoryService.editByCategory(this.promoCode).subscribe(flag=>{
      if(flag)
        alert("Promo Applied");
      else
        alert("PromoCode Not Applicable!");
    });
  }
}