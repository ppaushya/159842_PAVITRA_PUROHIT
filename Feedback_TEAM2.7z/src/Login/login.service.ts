import { Injectable } from "@angular/core";
import { HttpClient,  HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from "./login";



const header=new HttpHeaders({ 'Content-Type': 'application/json'})

@Injectable()
export class LoginServiceComponent
{
    private _loginUrl="";

    constructor(private _http: HttpClient){}

    isValidLogin(login: Login):Observable<boolean>
    {
       //console.log(this._http.get<boolean>(this._loginUrl+"/"+login.userName+"/"+login.userPassword))
       return this._http.get<boolean>(this._loginUrl+"/"+login.userName+"/"+login.userPassword);
    }

}