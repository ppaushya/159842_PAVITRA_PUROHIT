import { Component, OnInit } from "@angular/core";
import { Login } from "./login";
import { LoginServiceComponent } from "./login.service";
import { Router } from "@angular/router";


@Component({
    selector:'mad',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']

})
export class LoginComponent implements OnInit {
    login: Login;


    validLogin: boolean = true;
    constructor(private _loginService: LoginServiceComponent, private _router: Router) {

    }

    ngOnInit() {
       
    }

    navigate(): void {

        this._loginService.isValidLogin(this.login).subscribe(
            login => {
                this.validLogin = login;
                if (login) {

                    this._router.navigate(['/mainPage']);
                }
                else {
                    this.login.userName = "";
                    this.login.userPassword = "";
                    this._router.navigate(['/login']);
                }
            }
        )

    }

} 
