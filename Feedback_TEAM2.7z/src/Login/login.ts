export interface Login{
    userName:string;
    userPassword:string;
}