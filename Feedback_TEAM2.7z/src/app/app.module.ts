import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeedbackProductComponent } from './feedback-product/feedback-product.component';
import { FeedbackMerchantComponent } from './feedback-merchant/feedback-merchant.component';
import { LoginComponent } from 'src/Login/login.component';
import { LoginServiceComponent } from 'src/Login/login.service';

@NgModule({
  declarations: [
    AppComponent,
    FeedbackProductComponent,
    FeedbackMerchantComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [LoginServiceComponent],
  bootstrap: [AppComponent,FeedbackProductComponent]
})
export class AppModule { }
  