import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackMerchantComponent } from './feedback-merchant.component';

describe('FeedbackMerchantComponent', () => {
  let component: FeedbackMerchantComponent;
  let fixture: ComponentFixture<FeedbackMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
