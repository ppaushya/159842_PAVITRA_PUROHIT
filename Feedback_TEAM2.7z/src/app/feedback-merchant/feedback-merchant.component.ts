import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-merchant',
  templateUrl: './feedback-merchant.component.html',
  styleUrls: ['./feedback-merchant.component.css']
})
export class FeedbackMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
