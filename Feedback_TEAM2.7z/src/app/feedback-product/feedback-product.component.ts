import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-product',
  templateUrl: './feedback-product.component.html',
  styleUrls: ['./feedback-product.component.css']
})
export class FeedbackProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.tart();
    this.star();
    this.t_type1="far fa-thumbs-up";
    this.t_type2="far fa-thumbs-down";
  }

  rating: number;
  star_type1: string;
  star_type5: string;
  star_type4: string;
  star_type3: string;
  star_type2: string;

  st_type1: string;
  st_type5: string;
  st_type4: string;
  st_type3: string;
  st_type2: string;

  t_type1:string;
  t_type2:string;

  like: boolean;

  click(rating: number) {
    this.rating = rating;
    this.tart();
  }

  click2(rating: number) {
    this.rating = rating;
    this.star();
  }

  click3(like: boolean){
    this.like=like;
    this.thumbs();
  }

  tart() {
    this.star_type1 = "glyphicon glyphicon-star-empty";
    this.star_type2 = "glyphicon glyphicon-star-empty";
    this.star_type3 = "glyphicon glyphicon-star-empty";
    this.star_type4 = "glyphicon glyphicon-star-empty";
    this.star_type5 = "glyphicon glyphicon-star-empty";
    switch (this.rating) {
      case 1: this.star_type1 = "glyphicon glyphicon-star"; break;
      case 2: this.star_type1 = "glyphicon glyphicon-star";
        this.star_type2 = "glyphicon glyphicon-star";
        break;
      case 3: this.star_type1 = "glyphicon glyphicon-star";
        this.star_type2 = "glyphicon glyphicon-star";
        this.star_type3 = "glyphicon glyphicon-star";
        break;
      case 4: this.star_type1 = "glyphicon glyphicon-star";
        this.star_type2 = "glyphicon glyphicon-star";
        this.star_type3 = "glyphicon glyphicon-star";
        this.star_type4 = "glyphicon glyphicon-star";
        break;
      case 5: this.star_type1 = "glyphicon glyphicon-star";
        this.star_type2 = "glyphicon glyphicon-star";
        this.star_type3 = "glyphicon glyphicon-star";
        this.star_type4 = "glyphicon glyphicon-star";
        this.star_type5 = "glyphicon glyphicon-star";
        break;
    }
  }

  star() {
    this.st_type1 = "glyphicon glyphicon-star-empty";
    this.st_type2 = "glyphicon glyphicon-star-empty";
    this.st_type3 = "glyphicon glyphicon-star-empty";
    this.st_type4 = "glyphicon glyphicon-star-empty";
    this.st_type5 = "glyphicon glyphicon-star-empty";
    switch (this.rating) {
      case 1: this.st_type1 = "glyphicon glyphicon-star"; break;
      case 2: this.st_type1 = "glyphicon glyphicon-star";
        this.st_type2 = "glyphicon glyphicon-star";
        break;
      case 3: this.st_type1 = "glyphicon glyphicon-star";
        this.st_type2 = "glyphicon glyphicon-star";
        this.st_type3 = "glyphicon glyphicon-star";
        break;
      case 4: this.st_type1 = "glyphicon glyphicon-star";
        this.st_type2 = "glyphicon glyphicon-star";
        this.st_type3 = "glyphicon glyphicon-star";
        this.st_type4 = "glyphicon glyphicon-star";
        break;
      case 5: this.st_type1 = "glyphicon glyphicon-star";
        this.st_type2 = "glyphicon glyphicon-star";
        this.st_type3 = "glyphicon glyphicon-star";
        this.st_type4 = "glyphicon glyphicon-star";
        this.st_type5 = "glyphicon glyphicon-star";
        break;
    }
  }

  thumbs(){
   
    if (this.like){
      this.t_type1="fas fa-thumbs-up";
      this.t_type2="far fa-thumbs-down";
    }else{
      this.t_type1="far fa-thumbs-up";
      this.t_type2="fas fa-thumbs-down";
    }
  }


}
