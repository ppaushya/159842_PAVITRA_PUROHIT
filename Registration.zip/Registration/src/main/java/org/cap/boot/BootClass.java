package org.cap.boot;

import java.util.Scanner;

import org.cap.model.Registration;
import org.cap.service.RegistrationServiceImpl;
import org.cap.view.UserInteraction;

public class BootClass {
   
	public static void main(String[] args) {
		 Scanner scan=new Scanner(System.in);
		 UserInteraction userinteraction=new UserInteraction();
		 RegistrationServiceImpl regServiceImpl=new RegistrationServiceImpl();
		 Registration register=new Registration();
		int choice=0;
		System.out.println("1.Customer Registration");
		System.out.println("2.Exit");
		System.out.println("ENTER YOUR CHOICE:");
		choice=scan.nextInt();
		switch(choice) {
		case 1:register=userinteraction.addDetails();
		System.out.println(register);
		regServiceImpl.addRegistrationDetails(register);
			break;
		case 2:System.exit(0);
			break;
		default:System.out.println("INVALID CHOICE!");
			break;
		}
	}

}
