package org.cap.view;

import java.util.Scanner;

import org.cap.model.Registration;
import org.cap.util.Utility1;

public class UserInteraction {
	Utility1 uti=new Utility1();
	Scanner scan=new Scanner(System.in);
	public Registration addDetails() {
		
		Registration regs=new Registration();
		double registerFees;
		int age;
		
		System.out.println("Enter customer Name");
		regs.setCustomerName(getCustName());
		System.out.println("Enter Mobile number");
		regs.setMobileNo(getMobile());
		System.out.println("Enter registration fees:");
		registerFees=scan.nextDouble();
		regs.setRegistrationFees(registerFees);
		System.out.println("Enter age");
		age=scan.nextInt();
		regs.setAge(age);
		double total=calculateActualFees(age,registerFees);
		regs.setActualFeesPaid(calculateActualFees(age,registerFees));
		System.out.println("Total fees paid :"+total);
		
		return regs;
		
	}
	
	public String getCustName() {
		boolean flag=false;
		String customerName;
		do {
			customerName=scan.next();
			flag=uti.isCustomerNameValid(customerName);
			if(flag==false) {
		System.out.println("Invalid Customer Name!!!");
		
			}
		}while(flag==false);
		return customerName;
	}
	public String getMobile() {
		boolean flag=false;
		String MobileNo;
		do {
			MobileNo=scan.next();
			flag=uti.isMobileNumberValid(MobileNo);
			if(flag==false) {
		System.out.println("Invalid mobile number");
		
			}
		}while(flag==false);
		
		return MobileNo;
	}
	
	
	
	public double calculateActualFees(int age,double registerFees) {
		double comm=0;
		if(age>0&&age<18)
			comm=0;
		else if(age>18&&age<25)
			comm=0.1;
		else if(age>25&&age<50)
			comm=0.2;
		else 
			comm=0.3;
		
		double totalFees=0;
		totalFees=(registerFees*comm)+registerFees;
		
		return totalFees;
	}

}
