package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cap.model.Registration;

public class RegistrationDaoImpl implements IRegistrationDao{

	

	

	private Connection getDbConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","India123");
			return connection;
		}
		catch(ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void addregDetails(Registration register) throws ClassNotFoundException {
		Connection connection=null;
		try {
			connection=getDbConnection();
			String sql="INSERT INRO REGISTRATION VALUES (?,?,?,?,?)";
			PreparedStatement pst= connection.prepareStatement(sql);
			pst.setString(1, register.getCustomerName());
			pst.setString(2, register.getMobileNo());
			pst.setDouble(3, register.getRegistrationFees());
			pst.setInt(4, register.getAge());
			pst.setDouble(5, register.getActualFeesPaid());
			
			int count=pst.executeUpdate();
			
			
			if(count>=1)
			{
				System.out.println("insertion done!");
			}
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public Registration addRegistrationDetails(Registration register) {
		// TODO Auto-generated method stub
		//Connection connection=null;
		try(Connection conn=getDbConnection()) {
			//connection=getDbConnection();
			String sql="insert into registration(CustomerName,MobileNumber,RegistrationFees,age,ActualRegFeesPaid) values (?,?,?,?,?)";
			PreparedStatement pst= conn.prepareStatement(sql);
			pst.setString(1, register.getCustomerName());
			pst.setString(2, register.getMobileNo());
			pst.setDouble(3, register.getRegistrationFees());
			pst.setInt(4, register.getAge());
			pst.setDouble(5, register.getActualFeesPaid());
			
			int count=pst.executeUpdate();
			
			
			if(count>=1)
			{
				System.out.println("insertion done!");
			}
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return register;
	}
	

}
