package org.cap.util;

public class Utility1 {

	
	public boolean isMobileNumberValid(String MobileNo) {
		
		return MobileNo.matches("[7|8|9]{1}[0-9]{9}");
	}
	public boolean isCustomerNameValid(String customerName) {
		
		return customerName.matches("[a-zA-Z]{3,}");
	}
}
