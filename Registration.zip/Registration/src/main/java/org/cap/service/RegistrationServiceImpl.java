package org.cap.service;

import org.cap.dao.RegistrationDaoImpl;
import org.cap.model.Registration;

public class RegistrationServiceImpl implements IRegistrationService{

	RegistrationDaoImpl regDaoImpl=new RegistrationDaoImpl();
	
	@Override
	public void addRegistrationDetails(Registration register) {
		regDaoImpl.addRegistrationDetails(register);
		
	}

}
