package org.cap.model;

import java.time.LocalDate;

public class Account {

	private long accountNo;
	private AccountType accountType;
	private double openingBalance;
	private LocalDate openingDate;
	private String accountDescription;
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public String getAccountDescription() {
		return accountDescription;
	}
	public void setAccountDescription(String accountDescription) {
		this.accountDescription = accountDescription;
	}
	public Account(long accountNo, AccountType accountType, double openingBalance, LocalDate openingDate,
			String accountDescription) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.openingBalance = openingBalance;
		this.openingDate = openingDate;
		this.accountDescription = accountDescription;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", openingBalance=" + openingBalance
				+ ", openingDate=" + openingDate + ", accountDescription=" + accountDescription + "]";
	}
	public Account() {
		super();
	}
	
}
