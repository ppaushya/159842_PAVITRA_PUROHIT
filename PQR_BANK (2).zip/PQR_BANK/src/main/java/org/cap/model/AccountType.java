package org.cap.model;

public enum AccountType {

}
