package org.cap.view;

import java.time.LocalDate;
import java.util.Scanner;

import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.util.Utility;

public class UserInteraction {
	Scanner scan=new Scanner(System.in);

	public Customer getCustomerDetails() {
	
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateCustomerId());
		customer.setFirstName(getFirstName());
		customer.setLastName(getLastName());
		customer.setEmailId(getEmailId());
		customer.setMobileNo(getMobileNo());
		customer.setDateOfBirth(getDateOfBirth());
		customer.setAddress(getAddressDetails());
		return customer;
	}
	public Address getAddressDetails() {
		Address address=new Address();
		address.setAddressLine1(getAddressl1());
		address.setAddressLine2(getAddressl2());
		address.setCity(getCity());
		address.setState(getState());
		address.setPinCode(getPinCode());
		return address;
	}
	
	public String getAddressl1() {
		String addl1;
		System.out.println("ENTER ADDRESS LINE 1:");
		addl1=scan.next();
		return addl1;
	}
	public String getAddressl2() {
		String addl2;
		System.out.println("ENTER ADDRESS LINE 2:");
		addl2=scan.next();
		return addl2;
	}
	public String getCity() {
		String city;
		System.out.println("ENTER CITY:");
		city=scan.next();
		return city;
	}
	public String getState() {
		String state;
		System.out.println("ENTER STATE:");
		state=scan.next();
		return state;
	}
	public String getPinCode() {
		String pinCode;
		boolean flag=false;
		do {
		System.out.println("ENTER PIN CODE:");
		pinCode=scan.next();
		flag=Utility.isValidPinCode(pinCode);
		if(flag==false)
		System.out.println("Please enter valid pin code");
		}while(flag==false);
		return pinCode;
	}
	public String getFirstName() {
		String fName;
		boolean flag=false;
		do {
		System.out.println("ENTER FIRST NAME:");
	    fName=scan.next();
		flag=Utility.isValidName(fName);
		if(flag==false)
		System.out.println("Please enter valid first name");
		
		}while(flag==false);
		return fName;
	}
    public String getLastName() {
    	String lName;
    	boolean flag=false;
		do {
		System.out.println("ENTER LAST NAME:");
		lName=scan.next();
		flag=Utility.isValidName(lName);
		if(flag==false)
		System.out.println("Please enter valid last name");
		
		}while(flag==false);
		return lName;
	}
    public String getEmailId() {
    	String emailId;
    	boolean flag=false;
		do {
		System.out.println("ENTER EMAIL ID:");
		emailId=scan.next();
		flag=Utility.isValidEmail(emailId);
		if(flag==false)
		System.out.println("Please enter valid Email Id");
		
		}while(flag==false);
		return emailId;
    	
    }
    public String getMobileNo() {
    	String mobileNum;
    	boolean flag=false;
		do {
		System.out.println("ENTER MOBILE NUMBER:");
		mobileNum=scan.next();
		flag=Utility.isValidMobileNumber(mobileNum);
		if(flag==false)
		System.out.println("Please enter valid 10 didgit Mobile Number");
		}while(flag==false);
		return mobileNum;
    	
    }
    public LocalDate getDateOfBirth() {
    	String dateOb;
    	boolean flag=false;
    	do {
    	System.out.println("ENTER YOUR DATE OF BIRTH:(dd-MM-YYYY)");
    	dateOb=scan.next();
		flag=Utility.isValidDob(dateOb);
		if(flag==false)
			System.out.println("Please enter valid date of birth");
    	}while(flag==false);
    	String[] dates=dateOb.split("-");
		LocalDate dob=LocalDate.of(Integer.parseInt(dates[2]),Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		
		return dob;
    }
    
    
	
	
}
