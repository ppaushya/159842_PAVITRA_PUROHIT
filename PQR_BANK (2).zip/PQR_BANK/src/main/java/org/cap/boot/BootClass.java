package org.cap.boot;

import org.cap.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		UserInteraction ui=new UserInteraction();
		ui.getCustomerDetails();
		int choice=0;
		System.out.println("WELCOME TO PQR BANK");
		System.out.println("Please choose an option:");
		System.out.println("--------------------------------------------");
		System.out.println("1. CREATE CUSTOMER");
		System.out.println("2. LIST CUSTOMERS");
		
		switch(choice) {
		case 1:
			   break;
		case 2:
			   break;
		default:
			   break;
			  
		}

	}

}
