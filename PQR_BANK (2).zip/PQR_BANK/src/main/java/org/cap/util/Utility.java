package org.cap.util;



public class Utility {

	public static long generateCustomerId() {
		return (long)(Math.random()*1000)/10;
	}
	
	public static boolean isValidName(String name) {
		return name.matches("[a-zA-Z]{3,}");
	}
	public static boolean isValidEmail(String email) {
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}
	public static boolean isValidMobileNumber(String mobileNum) {
		return mobileNum.matches("[789]{1}[0-9]{9}");
	}
	public static boolean isValidDob(String dateOb) {
		return dateOb.matches("^\\d{2}-\\d{2}-\\d{4}$");
	}
	public static boolean isValidPinCode(String pin) {
		return pin.matches("[0-9]{6}");
	}
	

	
}
