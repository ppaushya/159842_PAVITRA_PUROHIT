package org.cap.view;

import java.time.LocalDate;
import java.util.Scanner;

import org.cap.model.Customer;
import org.cap.util.Utility;

public class UserInteraction {
	Scanner scan=new Scanner(System.in);

	public Customer getCustomerDetails() {
	
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateCustomerId());
		customer.setFirstName(getFirstName());
		customer.setLastName(getLastName());
		customer.setEmailId(getEmailId());
		customer.s
		return customer;
		
		
	}
	
	public String getFirstName() {
		String fName;
		boolean flag=false;
		do {
		System.out.println("ENTER FIRST NAME:");
	    fName=scan.next();
		flag=Utility.isValidName(fName);
		System.out.println("Please enter valid first name");
		
		}while(!flag);
		return fName;
	}
    public String getLastName() {
    	String lName;
    	boolean flag=false;
		do {
		System.out.println("ENTER LAST NAME:");
		lName=scan.next();
		flag=Utility.isValidName(lName);
		if(flag=false)
		System.out.println("Please enter valid last name");
		
		}while(!flag);
		return lName;
	}
    public String getEmailId() {
    	String emailId;
    	boolean flag=false;
		do {
		System.out.println("ENTER EMAIL ID:");
		emailId=scan.next();
		flag=Utility.isValidEmail(emailId);
		if(flag=false)
		System.out.println("Please enter valid Email Id");
		
		}while(!flag);
		return emailId;
    	
    }
    public String getMobileNo() {
    	String mobileNum;
    	boolean flag=false;
		do {
		System.out.println("ENTER MOBILE NUMBER:");
		mobileNum=scan.next();
		flag=Utility.isValidMobileNumber(mobileNum);
		if(flag=false)
		System.out.println("Please enter valid 10 didgit Mobile Number");
		}while(!flag);
		return mobileNum;
    	
    }
    public LocalDate getDateOfBirth() {
    	System.out.println("ENTER YOUR DATE OF BIRTH:");
    	System.out.println("ENTER YEAR:");
		int year=scan.nextInt();
		System.out.println("ENTER MONTH:");
		int month=scan.nextInt();
		System.out.println("ENTER DAY OF MONTH:");
		int dayOfMonth=scan.nextInt();
		LocalDate dob=LocalDate.of(year, month, dayOfMonth);
		return dob;
    }
    
    
	
	
}
