package org.cap.boot;

import org.cap.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		UserInteraction ui=new UserInteraction();
		ui.getFirstName();

	}

}
