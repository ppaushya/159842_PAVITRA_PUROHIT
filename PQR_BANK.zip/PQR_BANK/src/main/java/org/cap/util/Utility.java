package org.cap.util;



public class Utility {

	public static long generateCustomerId() {
		return (long)(Math.random()*1000)/10;
	}
	
	public static boolean isValidName(String name) {
		return name.matches("[A-Za-z]{3,}");
	}
	public static boolean isValidEmail(String email) {
		return email.matches("^[_A-Za-z0-9-]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\\\.(?:[A-Z]{2,}|com|org))*$");
	}
	public static boolean isValidMobileNumber(String mobileNum) {
		return mobileNum.matches("[7-9]{1}[0-9]{9}");
	}
}
