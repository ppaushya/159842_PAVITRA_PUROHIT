import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-coupons',
  templateUrl: './generate-coupons.component.html',
  styleUrls: ['./generate-coupons.component.css']
})
export class GenerateCouponsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
