import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Inventory } from './Inventory';
import { Observable } from 'rxjs';


const headers= new HttpHeaders({ 'Content-Type':'application/json'});

@Injectable({
  providedIn: 'root'
})
export class ProductService {

inventories:Inventory[];
  private custUrl='http://localhost:8081/day3-Spring5Rest/api/viewInventories';
  constructor(private http: HttpClient) { }

 getInventories(): Observable<Inventory[]>
 {

  console.log(('Inventories here!!'+this.http.get<Inventory[]>(this.custUrl)));
  return this.http.get<Inventory[]>(this.custUrl);
  
 }

 deleteInventory(inventoryId:number) :Observable<Inventory[]>
 {
this.custUrl=this.custUrl+'/'+inventoryId;
return this.http.delete<Inventory[]>(this.custUrl);
 }

 editInventory(inventory :Inventory):Observable<Inventory[]>{
   console.log('You can edit only quantity!!');
   return this.http.put<Inventory[]>('http://localhost:8081/day3-Spring5Rest/api/insertcustomers',inventory,{});
  
 }
}