package createAccount;

import java.time.LocalDate;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {

	
	private WebDriver webdriver;
	private WebElement element;
	
@Before
public void setUp() {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\papurohi\\Desktop\\chromedriver.exe" );
	webdriver=new ChromeDriver();
	
}
	

@Given("^Open CapgBanking Login Page$")
public void open_CapgBanking_Login_Page() throws Throwable {
	 webdriver.get("http://localhost:8081/CapgBanking/");
}

@Given("^provide username and password$")
public void provide_username_and_password() throws Throwable {
	webdriver.findElement(By.name("userName")).sendKeys("pavi@gmail.com");
    webdriver.findElement(By.name("userPwd")).sendKeys("pavi123");
}

@When("^Submit Validate Login$")
public void submit_Validate_Login() throws Throwable {
	element=webdriver.findElement(By.name("login"));
    element.submit();
}

@Then("^navigate to MainPage$")
public void navigate_to_MainPage() throws Throwable {
	 webdriver.navigate().to("http://localhost:8081/CapgBanking/loginServlet");
}

@When("^Submit Invalid Login$")
public void submit_Invalid_Login() throws Throwable {
//	Address address=new Address(123,"Zolo","Pristine Pvaillion","ChengalPattu","Tamil nadu","603002");
//	Customer customer = new Customer(123,"Shrey","Patel","")

	webdriver.navigate().to("http://localhost:8081/CapgBanking/");
	webdriver.findElement(By.name("userName")).sendKeys("pavi@gmail.com");
    webdriver.findElement(By.name("userPwd")).sendKeys("PAVI125465");
    element=webdriver.findElement(By.name("login"));
    element.submit();
    
}

@Then("^stay on CapgBanking Login Page with all fields empty$")
public void stay_on_CapgBanking_Login_Page_with_all_fields_empty() throws Throwable {
	
	webdriver.navigate().to("http://localhost:8081/CapgBanking/");
	webdriver.findElement(By.name("userName")).clear();
    webdriver.findElement(By.name("userPwd")).clear();
    
}

@When("^Click on Create account tab$")
public void click_on_Create_account_tab() throws Throwable {
    webdriver.findElement(By.linkText("Create Account")).click();
}

@Then("^Enter Account Details$")
public void enter_Account_Details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Click on Create account Button$")
public void click_on_Create_account_Button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}


}
