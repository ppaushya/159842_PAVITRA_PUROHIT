package register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {


private WebDriver webdriver;
private WebElement element;
	
	
	
@Before
public void setUp() {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\papurohi\\Desktop\\chromedriver.exe" );
	webdriver=new ChromeDriver();
	
}
	

@Given("^Open Capgbanking login page$")
public void open_Capgbanking_login_page() throws Throwable {
	webdriver.get("http://localhost:8081/CapgBanking/");
}

@When("^Click on SignUp$")
public void click_on_SignUp() throws Throwable {
	element=webdriver.findElement(By.name("signup"));
    element.submit();
}

@Then("^Navigate to SignUp page$")
public void navigate_to_SignUp_page() throws Throwable {
	 webdriver.get("http://localhost:8081/CapgBanking/view/registration.html");
}

@Then("^Enter Registration Information$")
public void enter_Registration_Information() throws Throwable {
	//First Name
    webdriver.findElement(By.name("firstName")).sendKeys("Mohit");
    //Last name
    webdriver.findElement(By.name("lastName")).sendKeys("Singh");
    //Date of birth
    WebElement BirthDate= webdriver.findElement(By.name("dateOfbirth"));
    BirthDate.clear();
    BirthDate.sendKeys("20-Aug-1985");
    
    //Address Line 1 & 2
    WebElement address1 = webdriver.findElement(By.name("addressline1"));
    address1.clear();
    address1.sendKeys("Nani Daman");
    
    WebElement address2 = webdriver.findElement(By.name("addressline2"));
    address2.clear();
    address2.sendKeys(" Daman");
    
    //City Drop Down List
    Select drpCity= new Select(webdriver.findElement(By.name("city")));
    drpCity.selectByVisibleText("Pune");
    
    //State Radio Button
    WebElement radio1=webdriver.findElement(By.id("1"));
    radio1.click();
    
    //Pincode
    webdriver.findElement(By.name("pincode")).sendKeys("396210");
    //EmailId
    webdriver.findElement(By.name("email")).sendKeys("mohit@gmail.com");
    //Mobile Number
    webdriver.findElement(By.name("mobile")).sendKeys("9871234567");
    //Password
    webdriver.findElement(By.name("custPwd")).sendKeys("mohit123");
    //Confirm Password
    webdriver.findElement(By.name("confirmCustPwd")).sendKeys("mohit123");
    
}

@When("^Click on Register$")
public void click_on_Register() throws Throwable {
	 element=webdriver.findElement(By.name("register"));
	 element.submit();
}


@Then("^Navigate to Login Page$")
public void navigate_to_Login_Page() throws Throwable {
	   webdriver.get("http://localhost:8081/CapgBanking/");
}


}
