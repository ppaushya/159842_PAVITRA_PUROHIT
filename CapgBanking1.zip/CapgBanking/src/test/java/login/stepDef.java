package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {

	private WebDriver webdriver;
	private WebElement element;
	
@Before
public void setUp() {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\papurohi\\Desktop\\chromedriver.exe" );
	webdriver=new ChromeDriver();
	
}
	

@Given("^Open CapgBanking Login Page$")
public void open_CapgBanking_Login_Page() throws Throwable {
   webdriver.get("http://localhost:8081/CapgBanking/");
}

@Given("^provide username and password$")
public void provide_username_and_password() throws Throwable {
    webdriver.findElement(By.name("userName")).sendKeys("pavi@gmail.com");
    webdriver.findElement(By.name("userPwd")).sendKeys("pavi123");
}

@When("^Submit Validate Login$")
public void submit_Validate_Login() throws Throwable {
	 element=webdriver.findElement(By.name("login"));
     element.submit();
   
}

@Then("^navigate to MainPage$")
public void navigate_to_MainPage() throws Throwable {
    webdriver.navigate().to("http://localhost:8081/CapgBanking/loginServlet");
    
}


@After
public void tearDown() {
//	webdriver.quit();
	
}


	
}
