package org.capg.service;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public class LoginServiceImpl implements ILoginService{

	private ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public Customer isValidLogin(LoginBean loginBean) {
			
		return loginDao.isValidLogin(loginBean);
	}

	@Override
	public boolean createCustomer(Customer customer) {
		
		return loginDao.createCustomer(customer);
	}

	@Override
	public Account createAccount(Account account) {
		
		return loginDao.createAccount(account);
	}

	@Override
	public List<Account> getAccounts(int custId) {
		
		return(loginDao.getAccounts(custId));
		
	}

	@Override
	public boolean addTransactionDetails(Transaction transaction) {
		// TODO Auto-generated method stub
		return (loginDao.addTransactionDetails(transaction));
	}

	@Override
	public List<Account> getToAccounts(int custId) {
		// TODO Auto-generated method stub
		return (loginDao.getToAccounts(custId));
	}

	@Override
	public double getCurrentBalance(int customerID, int accNo) {
		// TODO Auto-generated method stub
		return  (loginDao.getCurrentBalance(customerID, accNo));
	}
	
	@Override
	public List<Transaction> getAllTransactions(int custId, LocalDate fromDate, LocalDate toDate) {
		return loginDao.getAllTransactions(custId,fromDate,toDate);
	}
	
	@Override
	public LinkedList<Account> getAllAccount(int custId) {
		
		return loginDao.getAllAccount(custId);
	}
}
