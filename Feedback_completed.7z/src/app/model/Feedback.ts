import { Customer } from "./Customer";
import { Product } from "./Product";
import { Merchant } from "./Merchant";

export class Feedback {
    "feedbackId": number;
    "customer": Customer;
    "product": Product;
    "ratingProduct": number;
    "ratingMerchant": number;
    "comment":string
    "merchant":Merchant;
}