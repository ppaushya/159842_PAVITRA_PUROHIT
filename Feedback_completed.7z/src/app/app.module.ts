import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
//import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeedbackProductComponent } from './feedback-product/feedback-product.component';
import { FeedbackService } from './feedback-product/feedback.service';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
// import { LoginComponent } from 'src/Login/login.component';
// import { LoginServiceComponent } from 'src/Login/login.service';

@NgModule({
  declarations: [
    AppComponent,
    FeedbackProductComponent
    
  ],
  imports: [
    BrowserModule,
    //AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [FeedbackService],
  bootstrap: [AppComponent,FeedbackProductComponent]
})
export class AppModule { }
  