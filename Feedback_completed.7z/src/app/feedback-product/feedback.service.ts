import { Injectable } from '@angular/core';
import { Feedback } from '../model/Feedback';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';

const headers= new HttpHeaders({ 'Content-Type':'application/json'});

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  feedbacks:Feedback[];
  // Change the path
  private custUrl='http://localhost:8081/day3-Spring5Rest/api/viewInventories';
  constructor(private http: HttpClient) { }

  

  submitFeedback(feedback:Feedback):Observable<Boolean>{

      console.log("Your feedback submitted successfully!!");
     
      return this.http.put<Boolean>('http://localhost:8081/day3-Spring5Rest/api/insertcustomers',feedback,{});
  }
}
