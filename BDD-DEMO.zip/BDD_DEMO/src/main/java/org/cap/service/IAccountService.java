package org.cap.service;

import org.cap.exception.InsufficientBalanceException;
import org.cap.model.Account;
import org.cap.model.Customer;

public interface IAccountService {

	public Account createAccount(Customer customer,double openingBalance)
			throws InsufficientBalanceException;

	Account findAccount(int accountNo);
	public Account withdraw(int accountNo,double amount);
	public Account deposit(int accountNo, double amount);
	public Account[] fundTransfer(int fromAccountNo, int toAccountNo, double amount);
}
