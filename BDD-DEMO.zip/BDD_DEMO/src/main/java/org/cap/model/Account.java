package org.cap.model;

public class Account {

	private int accountNumber;
	private Customer customer;
	private double openingBalance;
	private String accountType;
	
	 
	
	public Account(int accountNumber, Customer customer, double openingBalance, String accountType) {
		super();
		this.accountNumber = accountNumber;
		this.customer = customer;
		this.openingBalance = openingBalance;
		this.accountType = accountType;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Account() {
		super();
	}

	public Account(int accountNumber, Customer customer, double openingBalance) {
		super();
		this.accountNumber = accountNumber;
		this.customer = customer;
		this.openingBalance = openingBalance;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", customer=" + customer + ", openingBalance="
				+ openingBalance + ", accountType=" + accountType + "]";
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNumber;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		long temp;
		temp = Double.doubleToLongBits(openingBalance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNumber != other.accountNumber)
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (Double.doubleToLongBits(openingBalance) != Double.doubleToLongBits(other.openingBalance))
			return false;
		return true;
	}

}
