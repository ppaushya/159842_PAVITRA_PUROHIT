package signup;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	@Given("^I will navigate to the Capg Banking login page$")
	public void i_will_navigate_to_the_Capg_Banking_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I click the SignUp$")
	public void i_click_the_SignUp() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will be on the Registration page$")
	public void i_will_be_on_the_Registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I have entered a Title$")
	public void i_have_entered_a_Title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I have entered a First Name$")
	public void i_have_entered_a_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I have entered a Email$")
	public void i_have_entered_a_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I click on the 'Register' button$")
	public void i_click_on_the_Register_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will get a popup displaying my account details$")
	public void i_will_get_a_popup_displaying_my_account_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will get an email with my account details$")
	public void i_will_get_an_email_with_my_account_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will navigate to the Admissions Portal login page$")
	public void i_will_navigate_to_the_Admissions_Portal_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
