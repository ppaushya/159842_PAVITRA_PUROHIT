package transaction;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountService;
import org.cap.service.IAccountService;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private Account account;
	private Account toAccount;
	private IAccountService accountService;
	private double amount;

	@Mock
	private IAccountDao accountDao;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService = new AccountService(accountDao);
		amount = 2500;
	}

	@Given("^Valid Account details$")
	public void valid_Account_details() throws Throwable {
		Account account = new Account();
		Address address = new Address("fORTUNE", "dAMAN");
		Customer customer = new Customer("Ram", "Singh", address);

		account.setAccountNumber(1001);
		account.setCustomer(customer);
		account.setOpeningBalance(3500);

		Address address2 = new Address("Chengalpattu", "Chennai");
		Customer customer2 = new Customer("rAJ", "Singh", address2);
		
		Account toAccount = new Account();
		toAccount.setAccountNumber(1002);
		toAccount.setCustomer(customer2);
		toAccount.setOpeningBalance(3500);
		
		// dummy declaration
		Mockito.when(accountDao.findAccount(1001)).thenReturn(account);
		Mockito.when(accountDao.findAccount(1002)).thenReturn(toAccount);

		// Actual Logic
		this.account = accountService.findAccount(1001);
		this.toAccount = accountService.findAccount(1002);

		// Mockito Verification
		Mockito.verify(accountDao).findAccount(1001);
		assertNotNull(this.account);
	}

	@Given("^Positive amount$")
	public void positive_amount() throws Throwable {
		assertTrue(this.amount > 0);
	}

	@When("^For valid balance in the account$")
	public void for_valid_balance_in_the_account() throws Throwable {
		assertTrue(this.account.getOpeningBalance() > this.amount);
	}

	@Then("^Perform account withdrawal$")
	public void perform_account_withdrawal() throws Throwable {
		Account account = accountService.withdraw(1001, this.amount);
		assertEquals(1500, account.getOpeningBalance(), 0.0);
	}

	@When("^Balance is positive$")
	public void balance_is_positive() throws Throwable {
		assertTrue(this.account.getOpeningBalance() > 0);
	}

	@Then("^Perform account deposit$")
	public void perform_account_deposit() throws Throwable {
		Account account = accountService.deposit(1001, this.amount);
		assertEquals(5500, account.getOpeningBalance(), 0.0);
	}

	@When("^For valid balance in from account$")
	public void for_valid_balance_in_from_account() throws Throwable {
		assertTrue(this.account.getOpeningBalance() > this.amount);
	}

	@Then("^Perform fund transfer deposit$")
	public void perform_fund_transfer_deposit() throws Throwable {
		Account accounts[] = accountService.fundTransfer(1001,1002, this.amount);
		assertEquals(1000, accounts[0].getOpeningBalance(), 0.0);
		assertEquals(5500, accounts[1].getOpeningBalance(), 0.0);
	}

}
