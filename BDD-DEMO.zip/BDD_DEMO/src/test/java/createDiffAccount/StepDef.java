package createDiffAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountService;
import org.cap.service.IAccountService;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

   private Customer customer;
   private IAccountService accountService;
   @Mock
   private IAccountDao accountDao;
   private Account account;
   
   
   @Before
   public void setUp() {
	   MockitoAnnotations.initMocks(this);
	   accountService=new AccountService(accountDao);
   }
  	
	
@Given("^Customer Details$")
public void customer_Details() throws Throwable {
	Address address = new Address("23 North avvenue", "Chennai");
	customer = new Customer("Tom", "Jerry", address);
   
}

@When("^For valid Customers with minimum opening balance (\\d+)$")
public void for_valid_Customers_with_minimum_opening_balance(int openingBalance) throws Throwable {
	
	assertNotNull(this.customer);
	account=new Account();
	account.setCustomer(this.customer);
	account.setOpeningBalance(openingBalance);
	
	Mockito.when(accountDao.createAccount(account)).thenReturn(true);
	this.account= accountService.createAccount(this.customer, openingBalance);
	Mockito.verify(accountDao).createAccount(account);
	
	
	
	
    
}

@Then("^Create new Savings account$")
public void create_new_Savings_account() throws Throwable {
   assertEquals("SAVINGS",this.account.getAccountType());
}

@Then("^Create new Current account$")
public void create_new_Current_account() throws Throwable {
	  assertEquals("CURRENT",this.account.getAccountType());
}

@Then("^Create new Rd account$")
public void create_new_Rd_account() throws Throwable {
	  assertEquals("RD",this.account.getAccountType());
}

@Then("^Create new Fd account$")
public void create_new_Fd_account() throws Throwable {
	  assertEquals("FD",this.account.getAccountType());
}


	




}
