function validate(){
	var userErrMsg = document.getElementById("userErrMsg");
	var passErrMsg = document.getElementById("passErrMsg");
	var username = loginform.username.value;
	var password = loginform.password.value;
	
	var success = false;
	
	if(username=="" || username==null){
		userErrMsg.innerHTML = "Please enter username";
		passErrMsg.innerHTML = "";
		success = false;
	}else if(password=="" || password==null){
		userErrMsg.innerHTML = "";
		passErrMsg.innerHTML = "Please enter password";
		success = false;
	}else{
		userErrMsg.innerHTML = "";
		passErrMsg.innerHTML = "";
		success = true;
	}
	
	return success;
}