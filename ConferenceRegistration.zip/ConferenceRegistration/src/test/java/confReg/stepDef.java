package confReg;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {

	private WebDriver webdriver;
	private WebElement element;
	
@Before
public void setUp() {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\papurohi\\Desktop\\chromedriver.exe" );
	webdriver=new ChromeDriver();
	
}	
	
	

@Given("^Open First Step page \\(Personal Details\\)$")
public void open_First_Step_page_Personal_Details() throws Throwable {
	webdriver.get("file:///C:/Users/papurohi/Downloads/Conferencebooking/ConferenceRegistartion.html#");
    
}

@When("^Title is 'Conference Registration'$")
public void title_is_Conference_Registration() throws Throwable {
	if(webdriver.getTitle().compareTo("Conference Registration")!=0)
	{
		System.out.println(webdriver.getTitle());
	    webdriver.quit();
	}
//    String title=webdriver.getTitle();
//    assertEquals("Conference Registartion", title);
//    webdriver.quit();
//	assertTrue(webdriver.getTitle().contains("Conference Registration"));
//	webdriver.switchTo().alert().sendKeys("You can");
//	
}

@When("^Heading is 'Step (\\d+): Personal Details'$")
public void heading_is_Step_Personal_Details(int arg1) throws Throwable {
//	webdriver.findElement(By.tagName("h4")).equals("Step 1: Personal Details");
//	 webdriver.quit();
	System.out.println(webdriver.findElement(By.tagName("h4")).getText());
	if(webdriver.findElement(By.tagName("h4")).getText().compareTo("Step 1: Personal Details")==0)
	{
	}
	else
	{
		webdriver.quit();
	}
}

@Then("^print message 'You can enter details now'$")
public void print_message_You_can_enter_details_now() throws Throwable {
	
	
}

@Given("^First Step Page$")
public void first_Step_Page() throws Throwable {
	webdriver.get("file:///C:/Users/papurohi/Downloads/Conferencebooking/ConferenceRegistartion.html#");
	Thread.sleep(3000);
}

@When("^All fields are present on web page$")
public void all_fields_are_present_on_web_page() throws Throwable {

if(webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("//*[@id=\"txtEmail\"]"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("//*[@id=\"txtAddress1\"]"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("//*[@id=\"txtAddress2\"]"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
if(webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"))!=null)
System.out.println("TRUE");
else
System.out.println("FALSE");
	
//	Alert alert=webdriver.switchTo().alert();
//	
//	alert.accept();

	
	
}

@Then("^Enter data for all fields & Validate data with appropriate alert message$")
public void enter_data_for_all_fields_Validate_data_with_appropriate_alert_message() throws Throwable {
	webdriver.findElement(By.name("txtFN")).sendKeys("Pavitra");
	webdriver.findElement(By.name("txtLN")).sendKeys("Purohit");
	webdriver.findElement(By.name("Email")).sendKeys("pavitra@gmail.com");
	webdriver.findElement(By.name("Phone")).sendKeys("7894561233");
	Select dropdown = new Select(webdriver.findElement(By.name("size")));
	dropdown.selectByVisibleText("3");
	webdriver.findElement(By.name("Address")).sendKeys("Zolo");
	webdriver.findElement(By.name("Address2")).sendKeys("Pune");
	Select dropdown1 = new Select(webdriver.findElement(By.name("city")));
	dropdown1.selectByVisibleText("Hyderabad");

	Select dropdown2 = new Select(webdriver.findElement(By.name("state")));
	dropdown2.selectByVisibleText("Telangana");
	WebElement radio1 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
	        //Radio Button1 is selected
	        radio1.click();
	        
	     WebElement radio2 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
	       
	        radio2.click();
	        
	      
	        WebElement click = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")); 
	       
	              
	        click.click(); 
	        
	                

	                
}

@Then("^Click on NEXT button$")
public void click_on_NEXT_button() throws Throwable {
	Alert alert=webdriver.switchTo().alert();
	System.out.println(alert.getText());
    Thread.sleep(3000);
	 webdriver.findElement(By.linkText(" Next ")).click();
	 webdriver.get("file:///C:/Users/papurohi/Downloads/Conferencebooking/PaymentDetails.html");
}




@When("^Second Page is opened \\(Payment Details\\)$")
public void second_Page_is_opened_Payment_Details() throws Throwable {
	webdriver.get("file:///C:/Users/papurohi/Downloads/Conferencebooking/PaymentDetails.html");
    
}

@Then("^Enter details$")
public void enter_details() throws Throwable {
	webdriver.findElement(By.name("txtFN")).sendKeys("Pavitra");
	webdriver.findElement(By.name("debit")).sendKeys("12345678902");
	webdriver.findElement(By.name("cvv")).sendKeys("123");
	webdriver.findElement(By.name("month")).sendKeys("Aug");
	webdriver.findElement(By.name("year")).sendKeys("2018");
	
}

@Then("^Click on MAKE PAYMENT Button$")
public void click_on_MAKE_PAYMENT_Button() throws Throwable {
	webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	Thread.sleep(3000);
}


	
	
	
	
	
}
