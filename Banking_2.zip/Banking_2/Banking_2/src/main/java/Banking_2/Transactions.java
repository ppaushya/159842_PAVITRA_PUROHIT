package day6miniproject;

import java.time.LocalDate;

public class Transactions {

	private int transid;
	
	private int amount;
	
	private float updated;
	
	
	public String getType() {
		return type;
	}

	public float getUpdated() {
		return updated;
	}

	public void setUpdated(float updated) {
		this.updated = updated;
	}


	private String type;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTransid() {
		return transid;
	}

	public void setTransid(int transid) {
		this.transid = transid;
	}

	

	public void setType(String type) {
		this.type = type;
	}

	
	public Transactions() {
		super();
	}
	
	
	
	
}
