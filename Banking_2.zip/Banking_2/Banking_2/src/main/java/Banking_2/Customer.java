package day6miniproject;

public class Customer {

	private int customerId;
	
	private String customerName;
	
	 Address address=new Address();
	
	 Account account[]=new Account[5];
	
	private String Email;
	private String Mobileno;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Customer()
	{
		
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getMobileno() {
		return Mobileno;
	}

	public void setMobileno(String mobileno) {
		Mobileno = mobileno;
	}
	
}
