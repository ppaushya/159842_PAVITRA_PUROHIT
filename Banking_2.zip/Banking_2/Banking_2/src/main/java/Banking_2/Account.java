package day6miniproject;

import java.time.LocalDate;

public class Account {

	private int accno;
	
	private String acctype;
	
	//private LocalDate openingdate;
	
	private float balance;
	
	Transactions trans[]=new Transactions[100];

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getAcctype() {
		return acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	
	public Account()
	{
		
	}
}
